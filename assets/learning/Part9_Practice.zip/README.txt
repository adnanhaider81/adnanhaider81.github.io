FASTQ TO PHYLOGENY | PART 9
FROM MAPPED READS TO A MASKED CONSENSUS GENOME
====================================================

AUDIENCE
Beginning bioinformatics learners coming from wet-lab backgrounds, using
Windows with WSL2/Ubuntu. This is a short-read, single-end, single-sample,
introductory haploid consensus exercise.

CONTINUITY WITH PARTS 7 AND 8
This lesson uses the same 2,400-base synthetic reference and the same
coverage pattern, including the 350-base gap at reference positions
1,051-1,400 (1-based, inclusive). For a more informative variant-calling
exercise, this ZIP contains an updated FASTQ with a deliberate synthetic
G>A change at position 877. It is therefore NOT byte-identical to the
Part 7/8 FASTQ file. Do not use the old FASTQ for this demonstration SNP.

INPUTS
reference.fasta       2,400-base synthetic reference
reads_part9.fastq.gz  300 synthetic single-end reads, 100 bp each
run_part9.sh          Optional all-in-one reproduction script
DATASET_DESIGN.txt    How the synthetic teaching reads were constructed

ALL DATA ARE ARTIFICIAL. They are not from real pathogens or patients.

FIRST-TIME SETUP
Open Ubuntu (WSL2) and install the tools:

  sudo apt update
  sudo apt install minimap2 samtools bcftools -y

Create your folder:

  mkdir -p ~/bioinformatics_training/part9
  cd ~/bioinformatics_training/part9
  explorer.exe .

Copy reference.fasta, reads_part9.fastq.gz and run_part9.sh from this ZIP
into the folder opened in Windows Explorer. Then return to Ubuntu:

  ls -lh reference.fasta reads_part9.fastq.gz

FOLLOW THE SLIDES OR RUN THE OPTIONAL SCRIPT

  bash run_part9.sh

MANUAL WORKFLOW (COPY THESE COMMANDS ONE LINE AT A TIME)

1. Mapping and depth:

  samtools faidx reference.fasta
  minimap2 -ax sr reference.fasta reads_part9.fastq.gz > mapped.sam
  samtools sort -o mapped.sorted.bam mapped.sam
  samtools index mapped.sorted.bam
  samtools depth -aa mapped.sorted.bam > depth.tsv

2. Make low-coverage BED mask from ALL reference positions:

  awk -v OFS='\t' '$3<10 {print $1,$2-1,$2}' depth.tsv > lowcov.bed

   - The depth file is 1-based; the BED mask is 0-based, half-open.
   - For reference position 1051, BED start is 1050.
   - The entire 1051-1400 zero-depth gap is therefore masked.
   - 10x is a chosen teaching threshold, NOT a universal standard.
   - The BAM's mapping/quality filters determine which bases contribute.

3. Call and filter candidate variants:

  bcftools mpileup -Ou -f reference.fasta mapped.sorted.bam > likelihoods.bcf
  bcftools call -mv --ploidy 1 -Oz -o variants.vcf.gz likelihoods.bcf
  bcftools index variants.vcf.gz
  bcftools filter -i 'QUAL>=30' -Oz -o passing.vcf.gz variants.vcf.gz
  bcftools index passing.vcf.gz

   This illustrates a haploid or dominant-allele approximation for a toy
   viral sequence. QUAL>=30 is only a simple example filter. Real variant
   calling must assess read-level evidence, allele fractions, mapping
   biases, strand support, local sequence context and platform chemistry.

4. Create an N-masked consensus FASTA:

  bcftools consensus -f reference.fasta -m lowcov.bed passing.vcf.gz > consensus.fa

   bcftools consensus applies listed alternate alleles from the VCF to
   the reference. All other unmasked sites stay as reference bases by
   default, which DOES NOT prove the sequence was observed at each site.
   Sites marked by lowcov.bed are converted to N. Mixed populations and
   minor variants are not represented fully by this single FASTA sequence.

5. Inspect the results:

  bcftools view -H passing.vcf.gz | head
  samtools faidx consensus.fa
  grep -v '^>' consensus.fa | tr -d '\n' | wc -c
  grep -v '^>' consensus.fa | tr -cd 'N' | wc -c

WHAT TO EXPECT
- Reference length: 2,400 bases.
- Synthetic SNP introduced: position 877 G>A, covered by >20 reads in
  the dataset design. Inspect the actual variant call before relying on it.
- Intentional zero-depth gap: 1,051-1,400 inclusive, 350 bases.
- The final consensus should have N at those uncovered positions, plus
  other positions below the chosen 10x threshold.
- Numbers depend on actual alignment, quality filters, and variant calls.

IMPORTANT SCIENTIFIC CAUTIONS
- This is a *teaching example*, not a clinical consensus SOP.
- A consensus FASTA is a summary, not proof of a single biological genome.
- Reference choice, low read depth, contamination, primer bias and mixtures
  can all change results; do not diagnose a particular wet-lab cause from
  a masked sequence alone.
- Variable-length indels require careful normalization and assessment.
- For clinical or surveillance pipelines, follow validated platform-
  specific thresholds and interpretation procedures.

OFFICIAL COMMAND REFERENCES
  https://samtools.github.io/bcftools/howtos/variant-calling.html
  https://samtools.github.io/bcftools/howtos/consensus-sequence.html
  https://samtools.github.io/bcftools/bcftools.html
  https://www.htslib.org/doc/samtools-depth.html

SERIES HOME
  https://syedadnanhaider.com/learn/bioinformatics-on-windows/
