#!/usr/bin/env bash
set -euo pipefail

# FASTQ TO PHYLOGENY | PART 9
# Run inside a folder containing reference.fasta and reads_part9.fastq.gz
# Requires minimap2, samtools, bcftools, awk and standard Ubuntu utilities.

for tool in minimap2 samtools bcftools awk; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "Missing: $tool. See README.txt for installation instructions." >&2
    exit 1
  fi
done
for file in reference.fasta reads_part9.fastq.gz; do
  if [[ ! -s "$file" ]]; then
    echo "Missing input file: $file" >&2
    exit 1
  fi
done

# Map and measure coverage.
samtools faidx reference.fasta
minimap2 -ax sr reference.fasta reads_part9.fastq.gz > mapped.sam
samtools sort -o mapped.sorted.bam mapped.sam
samtools index mapped.sorted.bam
samtools depth -aa mapped.sorted.bam > depth.tsv

# Introductory depth threshold: mask every position below 10 reads.
# BED intervals are zero-based and half-open.
awk -v OFS='\t' '$3<10 {print $1,$2-1,$2}' depth.tsv > lowcov.bed

# Call candidate variants; the teaching example treats the sample as haploid.
bcftools mpileup -Ou -f reference.fasta mapped.sorted.bam > likelihoods.bcf
bcftools call -mv --ploidy 1 -Oz -o variants.vcf.gz likelihoods.bcf
bcftools index variants.vcf.gz

# Simple QUAL threshold for teaching, not a clinical quality filter.
bcftools filter -i 'QUAL>=30' -Oz -o passing.vcf.gz variants.vcf.gz
bcftools index passing.vcf.gz

# Apply passing variants to the reference; mask low-depth sites as N.
bcftools consensus -f reference.fasta -m lowcov.bed passing.vcf.gz > consensus.fa
samtools faidx consensus.fa

printf '\n== VARIANT SITES PASSING QUAL FILTER ==\n'
bcftools view -H passing.vcf.gz || true
printf '\n== COVERAGE SUMMARY ==\n'
awk '{total++; if($3>=10)covered++; if($3==0)zero++} END {printf "Reference positions: %d; >=10x: %d; zero: %d\n",total,covered,zero}' depth.tsv
printf '\n== FINAL FASTA SUMMARY ==\n'
printf 'Sequence length (bases): '
grep -v '^>' consensus.fa | tr -d '\n' | wc -c
printf 'N characters: '
grep -v '^>' consensus.fa | tr -cd 'N' | wc -c
printf '\nConsensus FASTA: consensus.fa\n'
