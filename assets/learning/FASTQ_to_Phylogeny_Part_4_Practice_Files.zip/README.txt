FASTQ to Phylogeny - Part 4 practice files

fastqc_good.fastq.gz: 5,000 synthetic 100-bp reads with high per-base quality.
fastqc_tail_drop.fastq.gz: the same synthetic reads, with quality declining toward the read end.

These are teaching files only and are not biological sequencing data.

Author: Syed Adnan Haider
Website edition: 5 October 2026

Quality encoding: Phred+33 (Sanger / Illumina 1.9 in FastQC).
The high-quality file has Q40 calls except for the first base of the
first read, which is Q30. This single high-quality character makes
the encoding unambiguous to FastQC's automatic detection. An all-Q40
synthetic file can otherwise be interpreted as older Phred+64 data.
Read identifiers, sequences, read lengths, and read counts are unchanged.
The tail-drop file is unchanged.

Lesson and downloads:
https://syedadnanhaider.com/learn/bioinformatics-on-windows/part-4-fastqc.html
