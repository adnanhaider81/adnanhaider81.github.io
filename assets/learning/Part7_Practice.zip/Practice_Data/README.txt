FASTQ TO PHYLOGENY | PART 7 - REFERENCE MAPPING
==================================================

Audience: wet-lab scientists beginning command-line bioinformatics on a
Windows PC using WSL2 / Ubuntu.

These data are COMPLETELY SYNTHETIC and are NOT real virus sequences,
clinical material, or real sequencing results.

FILES
  reference.fasta  - synthetic, virus-like 2,400-base reference fragment
  reads.fastq.gz   - 300 synthetic single-end short reads, each 100 bases

Dataset construction:
  280 reads were generated from the reference, from positions covering
  the two flanks of the reference (with a central region deliberately
  left uncovered). 20 reads are unrelated synthetic background reads.
  A small number of reads contain one deliberate substitution, and some
  are reverse-complemented to illustrate mapping to either strand.
  These are DATA DESIGN NUMBERS, not guaranteed aligner outputs.

HOW TO USE ON WSL2 / UBUNTU
1. Install tools once:
   sudo apt update
   sudo apt install minimap2 samtools -y

2. Make your Part 7 folder:
   mkdir -p ~/bioinformatics_training/part7
   cd ~/bioinformatics_training/part7
   explorer.exe .

3. Copy reference.fasta and reads.fastq.gz from this ZIP into the
   folder opened by Windows Explorer. Back in Ubuntu, check:
   ls -lh reference.fasta reads.fastq.gz

4. Map the short reads (output is an ordinary text SAM file):
   minimap2 -ax sr reference.fasta reads.fastq.gz > mapped.sam

5. Sort the alignments into a BAM file:
   samtools sort -o mapped.sorted.bam mapped.sam

6. Create the BAM index:
   samtools index mapped.sorted.bam

7. Look at mapping statistics and count alignments that are mapped:
   samtools flagstat mapped.sorted.bam
   samtools view -c -F 4 mapped.sorted.bam

What to expect: Most reads should map. A minority were deliberately
created without a match. Mapping percentage is NOT the same as breadth
or depth of genome coverage. The central reference region was designed
with no matching reads; Part 8 will explain depth and breadth.

IMPORTANT INTERPRETATION NOTES
* The selected reference is an analytical comparison target, not proof
  of a sample's organism identity.
* 'Unmapped' means no suitable alignment to THIS reference under THESE
  mapping settings, not automatically a sequencing failure.
* BAM is a compressed binary alignment format; BAI is its index.
* This uses the short-read minimap2 preset (sr) and single-end reads.
  Long-read sequencing needs a different preset, which will be covered
  separately if desired.
* Small synthetic data run quickly. Real dataset interpretation must
  consider sequencing chemistry, reference selection, contamination,
  mapping quality, duplicate records, and other factors.

OFFICIAL TOOL GUIDANCE
Minimap2: https://github.com/lh3/minimap2
SAMtools: https://www.htslib.org/doc/

SERIES HOME
https://syedadnanhaider.com/learn/bioinformatics-on-windows/
