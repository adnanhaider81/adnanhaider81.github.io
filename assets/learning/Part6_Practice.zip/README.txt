FASTQ TO PHYLOGENY | PART 6
When to trim, filter, or leave reads unchanged
Author: Syed Adnan Haider
Website edition: 17 October 2026

PRACTICE FILES
- good.fq.gz: 5,000 synthetic 100-base single-end reads, predominantly Q40.
- tail.fq.gz: the same read sequences; 70 high-quality bases followed by 30 Q10 bases.
- adapter.fq.gz: 5,000 synthetic 100-base single-end reads; exactly 4,000 (80%)
  end with the known 33-base adapter. These reads contain a 67-base insert.
- a.fa: the known adapter sequence in FASTA format for targeted trimming.

The files are synthetic exercises. They are not clinical or biological samples.

QUALITY ENCODING IN THE WEBSITE EDITION
All three files use Phred+33 quality encoding. In EACH file, only the first
quality character of the first read was changed from I (Q40) to ? (Q30).
Q30 is still high quality. The other high-quality bases remain Q40, and the
30-base low-quality tail remains Q10. This one-character adjustment avoids
FastQC mistaking uniformly high-quality input or cleaned output for older
Phred+64 encoding. Every read identifier, sequence, read length, read count
and every other uncompressed byte is unchanged.

1. ONCE ONLY: INSTALL FASTP (inside Ubuntu/WSL2)
sudo apt update
sudo apt install fastp -y
fastp --version

2. CREATE THE PART 6 WORKING FOLDER
mkdir -p ~/bioinformatics_training/part6
cd ~/bioinformatics_training/part6
explorer.exe .

Use the Windows Explorer window to copy the FOUR extracted practice files
good.fq.gz, tail.fq.gz, adapter.fq.gz and a.fa into this folder.
Then verify in Ubuntu:
ls *.fq.gz a.fa

3. TRIM A LOW-QUALITY TAIL
fastp -i tail.fq.gz -o tail.clean.fq.gz -r -l 50 -h tail.fastp.html -j tail.fastp.json

4. REMOVE A KNOWN ADAPTER
fastp -i adapter.fq.gz -o a.clean.fq.gz --adapter_fasta a.fa -h adapter.fastp.html -j adapter.fastp.json

The commands above retain the slides' processing options. They add only
distinct -h and -j report names so that both sets of reports are preserved.
The shorter commands on the slides work, but their default fastp.html and
fastp.json reports are overwritten by the second command unless renamed.

These single-end demonstrations use fastp's normal default filtering as well
as the explicit options shown. The short -r option enables cut-right quality
trimming: scan from the start using a sliding window. In the tested version,
the first failing window triggers trimming from its first low-quality base
through the end of the read, retaining leading high-quality bases in that
window. The -l 50 option
discards reads shorter than 50 bases. With --adapter_fasta, fastp trims the
sequences supplied in a.fa in addition to its normal adapter processing.

5. COMPARE FASTQC REPORTS BEFORE AND AFTER
fastqc *.fq.gz
explorer.exe .

Open the *_fastqc.html reports in the Windows folder. With the three inputs
and two cleaned outputs present, this command produces five FastQC reports.
Compare Per base sequence quality, Adapter Content, read length and the
number of retained reads. The good file is an unprocessed comparison control.
The expected changes are removal of the Q10 tail from the tail example and
a large reduction in the adapter signal from the adapter example. Exact
output lengths and retained counts should be read from your own reports.

INTERPRETATION
Do not trim simply to obtain all-green FastQC icons. Shortening reads can
reduce useful biological information. For real data, use library- and
platform-specific settings, especially for paired-end, amplicon, long-read
or UMI workflows. Do not substitute these toy commands for a validated SOP.

SERIES HOME
https://syedadnanhaider.com/learn/bioinformatics-on-windows/
