FASTQ TO PHYLOGENY | PART 8 - DEPTH AND BREADTH OF COVERAGE
=================================================================
Author: Syed Adnan Haider

Audience: wet-lab scientists beginning bioinformatics on Windows with WSL2.

WHAT YOU RECEIVE
  reference.fasta     Synthetic reference from Part 7 (2,400 bp)
  reads.fastq.gz      300 synthetic single-end reads from Part 7
  DESIGN_NOTES.txt    Dataset construction and expected simulation metrics
  commands.sh         Optional script to reproduce the step-by-step commands

This is entirely SYNTHETIC teaching material; no biological or clinical data.

OPTION A: CONTINUE FROM PART 7 (RECOMMENDED)
You should already have mapped.sorted.bam and mapped.sorted.bam.bai in:
  ~/bioinformatics_training/part7

Open Ubuntu (WSL2) and run:
  cd ~/bioinformatics_training/part7
  ls -lh mapped.sorted.bam mapped.sorted.bam.bai
  samtools coverage mapped.sorted.bam
  samtools depth -aa mapped.sorted.bam > depth.tsv
  head depth.tsv
  wc -l depth.tsv

Inspect the intentional coverage gap:
  awk '$2>=1048 && $2<=1054' depth.tsv

Calculate breadth at >=1x and >=10x:
  awk '{n++; if($3>0)c++} END{print 100*c/n}' depth.tsv
  awk '{n++; if($3>=10)c++} END{print 100*c/n}' depth.tsv

These two commands print percentages. The third column of depth.tsv is
per-position read depth. Use the entire reference as the denominator,
including zero-depth positions. The -aa option includes unused reference
sequences and ensures zero-depth positions appear in output.

OPTION B: START FROM THIS ZIP
1. Install software if you did not complete Part 7:
  sudo apt update
  sudo apt install minimap2 samtools -y
2. Create the practice folder:
  mkdir -p ~/bioinformatics_training/part8
  cd ~/bioinformatics_training/part8
  explorer.exe .
3. Copy reference.fasta and reads.fastq.gz into that folder using Explorer.
4. Run:
  minimap2 -ax sr reference.fasta reads.fastq.gz > mapped.sam
  samtools sort -o mapped.sorted.bam mapped.sam
  samtools index mapped.sorted.bam
5. Continue with the samtools commands in Option A, in this part8 folder.

WHAT YOU SHOULD SEE
This dataset was designed to leave positions 1051 to 1400 of the reference
uncovered, even though many reads originated from that reference. If the
reads map as intended, breadth is around 85% at >=1x. Design numbers in
DESIGN_NOTES.txt are not a substitute for actual samtools measurements.

KEY INTERPRETATION
  Mapping rate: proportion of reads aligned to selected reference.
  Read depth: number of aligned read bases covering a reference position.
  Breadth: percentage of reference positions meeting a depth threshold.
  Mean depth: average depth across the specified region, including zeros.

A high mapping rate does not prove uniform or complete genome coverage.
A low-depth gap may reflect multiple wet-lab and computational factors.
Do not infer exact causes from a coverage plot alone.

The read depth output may vary based on alignment and filtering settings.
The examples here use single-end short reads and introductory defaults.

Official command help:
  https://www.htslib.org/doc/samtools-depth.html
  https://www.htslib.org/doc/samtools-coverage.html

Series home:
  https://syedadnanhaider.com/learn/bioinformatics-on-windows/

WEBSITE VALIDATION - 30 OCTOBER 2026
Tested in Ubuntu 22.04 with minimap2 2.24-r1122 and SAMtools 1.13.
All supplied commands and commands.sh worked with both existing BAM and
fresh input files. The depth table has 2,400 rows, including 350 zero-depth
positions at 1051-1400. Measured breadth: 85.4167% at >=1x and exactly
66.625% at >=10x. Mean depth: 11.6667x. Values may be displayed rounded.
The supplied FASTA and compressed FASTQ are unchanged from Part 7.
