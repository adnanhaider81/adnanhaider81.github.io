#!/usr/bin/env bash
# Author: Syed Adnan Haider
set -euo pipefail
# Part 8: run from the folder containing mapped.sorted.bam or reference + reads
command -v samtools >/dev/null || { echo 'Install samtools first.'; exit 1; }
if [[ ! -s mapped.sorted.bam ]]; then
  command -v minimap2 >/dev/null || { echo 'Install minimap2 first.'; exit 1; }
  [[ -s reference.fasta && -s reads.fastq.gz ]] || { echo 'Missing reference.fasta or reads.fastq.gz'; exit 1; }
  minimap2 -ax sr reference.fasta reads.fastq.gz > mapped.sam
  samtools sort -o mapped.sorted.bam mapped.sam
fi
if [[ ! -s mapped.sorted.bam.bai ]]; then samtools index mapped.sorted.bam; fi
samtools coverage mapped.sorted.bam | tee coverage_summary.tsv
samtools depth -aa mapped.sorted.bam > depth.tsv
printf '\nRows in depth.tsv: '; wc -l < depth.tsv
printf 'Breadth >=1x (percent): '
awk '{n++; if($3>0)c++} END{print 100*c/n}' depth.tsv
printf 'Breadth >=10x (percent): '
awk '{n++; if($3>=10)c++} END{print 100*c/n}' depth.tsv
printf 'Mean depth across reference (x): '
awk '{sum+=$3} END{print sum/NR}' depth.tsv
printf '\nDepth around 1051:\n'
awk '$2>=1048 && $2<=1054' depth.tsv
